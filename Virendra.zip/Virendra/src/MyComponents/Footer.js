import React from 'react'

export default function Footer() {
  return (
    <div>
  <footer>
    <small>
      Feedback @ dahale22@gmail.com
    </small>
  </footer>
    </div>
  )
}
