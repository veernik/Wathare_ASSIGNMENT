import React from 'react'

export default function Livegraph() {
  return (
    <div>
      <>Livegraph test</>
    </div>
  )
}
